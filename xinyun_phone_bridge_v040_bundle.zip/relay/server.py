import base64, json, os, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

DEVICE_TOKEN = os.environ.get('BRIDGE_DEVICE_TOKEN','')
JOB_B64 = os.environ.get('BRIDGE_JOB_B64','')
PORT = int(os.environ.get('PORT','10000'))
VERSION = '0.4.0-remote-read'

def decode_job():
    if not JOB_B64:
        return None
    try:
        pad = '=' * (-len(JOB_B64) % 4)
        raw = base64.urlsafe_b64decode((JOB_B64 + pad).encode())
        job = json.loads(raw.decode('utf-8'))
        if not isinstance(job, dict): return None
        if not isinstance(job.get('job_id'), str): return None
        if job.get('kind') not in ('sms.search','sms.stats','sms.get'): return None
        if not isinstance(job.get('payload',{}), dict): return None
        return job
    except Exception as e:
        print('JOB_DECODE_ERROR '+type(e).__name__, flush=True)
        return None

CURRENT_JOB = decode_job()

def b64j(obj):
    raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')

class H(BaseHTTPRequestHandler):
    server_version='XinyunBridge/'+VERSION
    def log_message(self, fmt, *args):
        print('HTTP '+(fmt%args), flush=True)
    def sendj(self, code, obj):
        raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers(); self.wfile.write(raw)
    def bearer(self):
        a=self.headers.get('Authorization','')
        return a[7:] if a.startswith('Bearer ') else ''
    def auth_device(self):
        if not DEVICE_TOKEN or self.bearer()!=DEVICE_TOKEN:
            self.sendj(401,{'detail':'unauthorized'}); return False
        return True
    def readj(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            return json.loads(self.rfile.read(n) or b'{}')
        except Exception:
            return None
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/health':
            return self.sendj(200,{'ok':True,'version':VERSION,'job_loaded':bool(CURRENT_JOB)})
        if path=='/v1/device/job':
            if not self.auth_device(): return
            return self.sendj(200,{'job':CURRENT_JOB})
        return self.sendj(404,{'detail':'not found'})
    def do_POST(self):
        path=urlparse(self.path).path
        if not self.auth_device(): return
        body=self.readj()
        if body is None: return self.sendj(400,{'detail':'invalid json'})
        parts=path.strip('/').split('/')
        if len(parts)==5 and parts[:3]==['v1','device','job'] and parts[4]=='result':
            job_id=parts[3]
            if not CURRENT_JOB or job_id!=CURRENT_JOB.get('job_id'):
                return self.sendj(409,{'detail':'job mismatch'})
            if body.get('done') is True:
                total=int(body.get('total',0))
                print(f'SMS_DONE job={job_id} total={total}', flush=True)
                return self.sendj(200,{'ok':True})
            seq=int(body.get('seq',0))
            rows=body.get('messages')
            if not isinstance(rows,list): return self.sendj(422,{'detail':'messages required'})
            for i,row in enumerate(rows):
                if isinstance(row,dict):
                    print(f'SMS_RESULT job={job_id} seq={seq} i={i} data={b64j(row)}', flush=True)
            return self.sendj(200,{'ok':True,'accepted':len(rows)})
        return self.sendj(404,{'detail':'not found'})

if __name__=='__main__':
    print(f'BRIDGE_READY version={VERSION} port={PORT} job={CURRENT_JOB.get("job_id") if CURRENT_JOB else "none"}', flush=True)
    ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
