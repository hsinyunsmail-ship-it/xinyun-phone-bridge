import base64, json, os, secrets, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DEVICE_TOKEN = os.environ.get('BRIDGE_DEVICE_TOKEN','')
CLIENT_TOKEN = os.environ.get('BRIDGE_CLIENT_TOKEN','')
JOB_B64 = os.environ.get('BRIDGE_JOB_B64','')
PORT = int(os.environ.get('PORT','10000'))
VERSION = '0.4.2-remote-read'
MAX_RESULT_PAGE = 200
LOCK = threading.Lock()


def decode_job():
    if not JOB_B64:
        return None
    try:
        pad = '=' * (-len(JOB_B64) % 4)
        raw = base64.urlsafe_b64decode((JOB_B64 + pad).encode())
        job = json.loads(raw.decode('utf-8'))
        if not isinstance(job, dict): return None
        if not isinstance(job.get('job_id'), str): return None
        if job.get('kind') not in ('sms.search','sms.stats','sms.get'): return None
        if not isinstance(job.get('payload',{}), dict): return None
        return job
    except Exception as e:
        print('JOB_DECODE_ERROR '+type(e).__name__, flush=True)
        return None


def fresh_state(job):
    return {
        'job': job,
        'status': 'pending',
        'messages': [],
        'seqs': set(),
        'total': None,
        'created_at': time.time(),
        'completed_at': None,
    }

LEGACY_JOB = decode_job()
STATE = fresh_state(LEGACY_JOB) if LEGACY_JOB else None


def safe_int(v, default, lo, hi):
    try: n = int(v)
    except Exception: n = default
    return max(lo, min(hi, n))


def client_ok(q):
    vals = q.get('token', [])
    return bool(CLIENT_TOKEN) and bool(vals) and secrets.compare_digest(vals[0], CLIENT_TOKEN)


def redacted_path(raw):
    p = urlparse(raw)
    q = parse_qs(p.query, keep_blank_values=True)
    if 'token' in q: q['token'] = ['REDACTED']
    if not q: return p.path
    from urllib.parse import urlencode
    return p.path + '?' + urlencode({k:v[0] if len(v)==1 else v for k,v in q.items()}, doseq=True)


class H(BaseHTTPRequestHandler):
    server_version='XinyunBridge/'+VERSION
    def log_message(self, fmt, *args):
        # Do not write client auth tokens to app logs.
        msg = fmt % args
        if self.path:
            msg = msg.replace(self.path, redacted_path(self.path))
        print('HTTP '+msg, flush=True)
    def sendj(self, code, obj):
        raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers(); self.wfile.write(raw)
    def bearer(self):
        a=self.headers.get('Authorization','')
        return a[7:] if a.startswith('Bearer ') else ''
    def auth_device(self):
        if not DEVICE_TOKEN or not secrets.compare_digest(self.bearer(), DEVICE_TOKEN):
            self.sendj(401,{'detail':'unauthorized'}); return False
        return True
    def auth_client(self, q):
        if not client_ok(q):
            self.sendj(401,{'detail':'unauthorized'}); return False
        return True
    def readj(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            return json.loads(self.rfile.read(n) or b'{}')
        except Exception:
            return None

    def do_GET(self):
        global STATE
        p=urlparse(self.path); path=p.path; q=parse_qs(p.query)
        if path=='/health':
            with LOCK:
                s=STATE
                return self.sendj(200,{'ok':True,'version':VERSION,'job_loaded':bool(s and s.get('job')),'status':s.get('status') if s else None})

        if path=='/v1/device/job':
            if not self.auth_device(): return
            with LOCK:
                job = STATE.get('job') if STATE and STATE.get('status') in ('pending','claimed') else None
                if job and STATE['status']=='pending': STATE['status']='claimed'
                return self.sendj(200,{'job':job})

        # Temporary ChatGPT read-only shim. token is intentionally query-based because
        # the current chat web fetcher cannot attach an Authorization header.
        if path=='/v1/client/dispatch':
            if not self.auth_client(q): return
            kind=q.get('kind',['sms.search'])[0]
            if kind not in ('sms.search','sms.stats','sms.get'):
                return self.sendj(422,{'detail':'invalid kind'})
            payload={}
            if kind=='sms.search':
                payload['query']=q.get('query',[''])[0]
                payload['state']=q.get('state',['all'])[0]
                payload['limit']=safe_int(q.get('limit',['10000'])[0],10000,1,10000)
                if 'after_ms' in q: payload['after_ms']=safe_int(q['after_ms'][0],0,0,2**63-1)
                if 'before_ms' in q: payload['before_ms']=safe_int(q['before_ms'][0],2**63-1,0,2**63-1)
            elif kind=='sms.get':
                ids=[]
                for s in q.get('ids',['']):
                    for part in s.split(','):
                        try: ids.append(int(part))
                        except Exception: pass
                payload['ids']=ids[:1000]
                payload['limit']=len(payload['ids']) or 1
            else:
                payload['query']=q.get('query',[''])[0]
                payload['state']=q.get('state',['all'])[0]
                payload['limit']=safe_int(q.get('limit',['10000'])[0],10000,1,10000)
            job={'job_id':'chat-'+secrets.token_urlsafe(10),'kind':kind,'payload':payload}
            with LOCK:
                STATE=fresh_state(job)
            return self.sendj(200,{'ok':True,'job_id':job['job_id'],'kind':kind,'status':'pending'})

        if path=='/v1/client/result':
            if not self.auth_client(q): return
            job_id=q.get('job_id',[''])[0]
            offset=safe_int(q.get('offset',['0'])[0],0,0,1000000)
            limit=safe_int(q.get('limit',['100'])[0],100,1,MAX_RESULT_PAGE)
            with LOCK:
                s=STATE
                if not s or not s.get('job') or s['job'].get('job_id')!=job_id:
                    return self.sendj(404,{'detail':'job not found'})
                msgs=s['messages']
                page=msgs[offset:offset+limit]
                return self.sendj(200,{
                    'job_id':job_id,'status':s['status'],'total':s['total'],
                    'received':len(msgs),'offset':offset,'count':len(page),
                    'next_offset':offset+len(page) if offset+len(page)<len(msgs) else None,
                    'messages':page,
                })
        return self.sendj(404,{'detail':'not found'})

    def do_POST(self):
        global STATE
        p=urlparse(self.path); path=p.path
        if not self.auth_device(): return
        body=self.readj()
        if body is None: return self.sendj(400,{'detail':'invalid json'})
        parts=path.strip('/').split('/')
        if len(parts)==5 and parts[:3]==['v1','device','job'] and parts[4]=='result':
            job_id=parts[3]
            with LOCK:
                s=STATE
                if not s or not s.get('job') or job_id!=s['job'].get('job_id'):
                    return self.sendj(409,{'detail':'job mismatch'})
                if body.get('done') is True:
                    s['total']=int(body.get('total',len(s['messages'])))
                    s['status']='completed'; s['completed_at']=time.time()
                    print(f'SMS_DONE job={job_id} total={s["total"]}', flush=True)
                    return self.sendj(200,{'ok':True})
                seq=int(body.get('seq',0)); rows=body.get('messages')
                if not isinstance(rows,list): return self.sendj(422,{'detail':'messages required'})
                if seq not in s['seqs']:
                    s['seqs'].add(seq)
                    s['messages'].extend(r for r in rows if isinstance(r,dict))
                print(f'SMS_BATCH job={job_id} seq={seq} accepted={len(rows)} received={len(s["messages"])}', flush=True)
                return self.sendj(200,{'ok':True,'accepted':len(rows),'received':len(s['messages'])})
        return self.sendj(404,{'detail':'not found'})

if __name__=='__main__':
    with LOCK:
        jid = STATE['job']['job_id'] if STATE and STATE.get('job') else 'none'
    print(f'BRIDGE_READY version={VERSION} port={PORT} job={jid}', flush=True)
    ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
