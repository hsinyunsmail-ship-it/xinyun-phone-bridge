package tw.xinyun.smsreadonly;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;
public final class BootReceiver extends BroadcastReceiver{
    @Override public void onReceive(Context c,Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) && c.getSharedPreferences("bridge",0).getBoolean("enabled",false)){
            try{c.startForegroundService(new Intent(c,BridgeService.class));}catch(RuntimeException ignored){}
        }
    }
}
