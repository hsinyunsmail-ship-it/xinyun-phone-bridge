package tw.xinyun.smsreadonly;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.IBinder;
import android.provider.Telephony;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class BridgeService extends Service {
    private volatile boolean running=true; private Thread loop;
    private static final String CH="xinyun_bridge_remote";
    @Override public void onCreate(){super.onCreate(); createChannel(); startForeground(40,notification("已連線，等待予安唯讀任務"));}
    @Override public int onStartCommand(Intent i,int flags,int id){ if(loop==null || !loop.isAlive()){running=true;loop=new Thread(this::runLoop,"xinyun-bridge");loop.start();} return START_STICKY; }
    @Override public void onDestroy(){running=false;getSharedPreferences("bridge",0).edit().putBoolean("enabled",false).apply();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private void createChannel(){NotificationManager nm=getSystemService(NotificationManager.class); if(nm.getNotificationChannel(CH)==null)nm.createNotificationChannel(new NotificationChannel(CH,"欣昀手機橋遠端唯讀",NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(String text){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CH).setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("欣昀手機橋｜遠端唯讀已啟用").setContentText(text).setOngoing(true).setContentIntent(pi).build();}
    private void setStatus(String s){getSharedPreferences("bridge",0).edit().putString("last_status",s).apply();getSystemService(NotificationManager.class).notify(40,notification(s));}
    private void runLoop(){
        while(running){try{JSONObject root=getJson(Secrets.BASE_URL+"/v1/device/job");JSONObject job=root.optJSONObject("job");if(job!=null){String id=job.optString("job_id","");String last=getSharedPreferences("bridge",0).getString("last_job","");if(!id.isEmpty()&&!id.equals(last)){execute(job);}}Thread.sleep(5000);}catch(Exception e){setStatus("連線暫時不可用，會自動重試");try{Thread.sleep(10000);}catch(InterruptedException ignored){}}}
    }
    private void execute(JSONObject job)throws Exception{
        if(checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED){setStatus("任務受阻：READ_SMS 未授權");return;}
        String id=job.getString("job_id"), kind=job.optString("kind","sms.search");JSONObject p=job.optJSONObject("payload");if(p==null)p=new JSONObject();
        setStatus("正在執行："+kind);
        JSONArray rows=querySms(kind,p); int total=rows.length(); int batch=20,seq=0;
        for(int off=0;off<total;off+=batch){JSONArray part=new JSONArray();for(int j=off;j<Math.min(total,off+batch);j++)part.put(rows.getJSONObject(j));JSONObject body=new JSONObject();body.put("seq",seq++);body.put("messages",part);postJson(Secrets.BASE_URL+"/v1/device/job/"+url(id)+"/result",body);}
        JSONObject done=new JSONObject();done.put("done",true);done.put("total",total);postJson(Secrets.BASE_URL+"/v1/device/job/"+url(id)+"/result",done);
        getSharedPreferences("bridge",0).edit().putString("last_job",id).apply();setStatus("上次任務完成："+total+" 筆");
    }
    private JSONArray querySms(String kind,JSONObject p)throws Exception{
        String q=p.optString("query","").trim().toLowerCase(Locale.ROOT);String state=p.optString("state","all");long after=p.optLong("after_ms",Long.MIN_VALUE);long before=p.optLong("before_ms",Long.MAX_VALUE);int limit=p.optInt("limit",10000);if(limit<1)limit=1;if(limit>10000)limit=10000;
        Set<Long> ids=new HashSet<>();JSONArray idsJson=p.optJSONArray("ids");if(idsJson!=null)for(int i=0;i<idsJson.length();i++)ids.add(idsJson.optLong(i,-1));
        JSONArray out=new JSONArray();String[] proj={"_id","date","address","body","type","read"};
        try(Cursor c=getContentResolver().query(Telephony.Sms.CONTENT_URI,proj,null,null,"date DESC")){
            if(c==null)return out;while(c.moveToNext() && out.length()<limit){long id=c.getLong(0),date=c.getLong(1);String addr=String.valueOf(c.getString(2));String body=String.valueOf(c.getString(3));int type=c.getInt(4);boolean read=c.getInt(5)==1;
                if("sms.get".equals(kind)&&!ids.contains(id))continue;if(date<after||date>before)continue;if("unread".equals(state)&&read)continue;if("read".equals(state)&&!read)continue;String hay=(addr+"\n"+body).toLowerCase(Locale.ROOT);if(!q.isEmpty()&&!hay.contains(q))continue;
                JSONObject m=new JSONObject();m.put("id",id);m.put("date",date);m.put("address",addr);m.put("body",body);m.put("type",type);m.put("read",read);out.put(m);
            }
        }
        return out;
    }
    private JSONObject getJson(String u)throws Exception{HttpURLConnection c=open(u,"GET");int code=c.getResponseCode();if(code/100!=2)throw new IOException("HTTP "+code);return new JSONObject(readAll(c.getInputStream()));}
    private void postJson(String u,JSONObject body)throws Exception{HttpURLConnection c=open(u,"POST");c.setDoOutput(true);byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setFixedLengthStreamingMode(data.length);try(OutputStream o=c.getOutputStream()){o.write(data);}int code=c.getResponseCode();if(code/100!=2)throw new IOException("HTTP "+code);}
    private HttpURLConnection open(String u,String method)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("Authorization","Bearer "+Secrets.DEVICE_TOKEN);c.setRequestProperty("Cache-Control","no-cache");return c;}
    private static String readAll(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[4096];int n;while((n=in.read(x))>0)b.write(x,0,n);return b.toString("UTF-8");}
    private static String url(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
}
