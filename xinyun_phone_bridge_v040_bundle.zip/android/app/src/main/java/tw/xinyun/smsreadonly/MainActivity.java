package tw.xinyun.smsreadonly;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}    
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    @Override protected void onResume(){super.onResume(); refresh();}
    private void build(){
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(28),dp(18),dp(28)); root.setBackgroundColor(Color.rgb(247,248,244)); sc.addView(root); setContentView(sc);
        label(root,"欣昀手機橋",28); label(root,"遠端唯讀橋 0.4.0",18);
        label(root,"用途：讓予安在你已啟用橋接後，從家裡直接查詢手機上的文字簡訊。\n\n本版只會回傳『予安當次任務命中的簡訊』；不會主動整庫上傳，不會發送、刪除、修改或標記已讀。啟用後會有常駐通知，你可隨時停止。",15);
        status=label(root,"",15);
        button(root,"① 授予／檢查簡訊唯讀權限",()->requestSms());
        button(root,"② 啟用予安遠端唯讀橋",()->startBridge());
        button(root,"停止遠端橋",()->{stopService(new Intent(this,BridgeService.class)); refresh();});
        button(root,"查看本程式權限設定",()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()))));
        label(root,"安全邊界：READ_SMS + 網路 + 遠端通訊前景服務。沒有 SEND_SMS、WRITE_SMS，也不是預設簡訊 App。",14);
        refresh();
    }
    private TextView label(LinearLayout r,String s,int sp){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(Color.rgb(25,30,28));v.setPadding(0,dp(8),0,dp(8));r.addView(v);return v;}
    private Button button(LinearLayout r,String s,Runnable a){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->a.run());r.addView(b);return b;}
    private boolean smsGranted(){return checkSelfPermission(Manifest.permission.READ_SMS)==PackageManager.PERMISSION_GRANTED;}
    private void requestSms(){
        if(smsGranted()){toastDialog("簡訊唯讀權限已授予","目前可以讀取手機本機文字簡訊。下一步按『② 啟用予安遠端唯讀橋』。"); return;}
        requestPermissions(new String[]{Manifest.permission.READ_SMS},41);
    }
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);refresh();}
    private void startBridge(){
        if(!smsGranted()){toastDialog("還不能啟用","請先完成① READ_SMS 唯讀授權。"); return;}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);
        }
        startForegroundService(new Intent(this,BridgeService.class));
        getSharedPreferences("bridge",0).edit().putBoolean("enabled",true).apply();
        toastDialog("遠端唯讀橋已啟用","之後予安可以送出唯讀查詢任務。手機橋只回傳該次查詢命中的簡訊；你可隨時按『停止遠端橋』。\n\n請回家17告訴予安：0.4 已啟用。");
        refresh();
    }
    private void refresh(){if(status==null)return; boolean e=getSharedPreferences("bridge",0).getBoolean("enabled",false);String last=getSharedPreferences("bridge",0).getString("last_status","尚未執行遠端任務");status.setText("READ_SMS："+(smsGranted()?"已授予":"未授予")+"\n遠端橋設定："+(e?"已啟用":"未啟用")+"\n狀態："+last);}
    private void toastDialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("知道了",null).show();}
}
