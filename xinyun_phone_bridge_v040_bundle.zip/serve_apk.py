import os
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
PORT=int(os.getenv('PORT','10000')); CODE=os.getenv('APK_DOWNLOAD_CODE',''); APK=os.path.join(os.path.dirname(__file__),'apk','xinyun-phone-bridge-0.4.0.apk')
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  p=urlparse(self.path)
  if p.path=='/health':
   b=b'ok';self.send_response(200);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
  if p.path!='/download' or not CODE or parse_qs(p.query).get('code',[''])[0]!=CODE:
   self.send_response(404);self.end_headers();return
  try:b=open(APK,'rb').read()
  except FileNotFoundError:self.send_response(503);self.end_headers();return
  self.send_response(200);self.send_header('Content-Type','application/vnd.android.package-archive');self.send_header('Content-Disposition','attachment; filename="xinyun-phone-bridge-0.4.0.apk"');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
