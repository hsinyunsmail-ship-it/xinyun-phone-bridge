#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${BRIDGE_DEVICE_TOKEN:?missing BRIDGE_DEVICE_TOKEN}"
: "${BRIDGE_BASE_URL:?missing BRIDGE_BASE_URL}"
SDK="$ROOT/.android-sdk"; GRADLE="$ROOT/.gradle-dist"; JDK="$ROOT/.jdk17"
mkdir -p "$SDK/cmdline-tools" "$GRADLE" "$JDK"
if [ ! -x "$JDK/bin/java" ]; then
  curl -fsSL "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" -o "$ROOT/jdk17.tar.gz"
  tar -xzf "$ROOT/jdk17.tar.gz" -C "$JDK" --strip-components=1
fi
export JAVA_HOME="$JDK" PATH="$JDK/bin:$PATH"
java -version
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -fsSL https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -o "$ROOT/cmdline.zip"
  rm -rf "$ROOT/cmdline-tmp"; mkdir -p "$ROOT/cmdline-tmp"; unzip -q "$ROOT/cmdline.zip" -d "$ROOT/cmdline-tmp"
  rm -rf "$SDK/cmdline-tools/latest"; mv "$ROOT/cmdline-tmp/cmdline-tools" "$SDK/cmdline-tools/latest"
fi
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"
yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
"$SDK/cmdline-tools/latest/bin/sdkmanager" "platforms;android-36" "build-tools;35.0.0" "platform-tools" >/dev/null
if [ ! -x "$GRADLE/gradle-8.11.1/bin/gradle" ]; then
  curl -fsSL https://services.gradle.org/distributions/gradle-8.11.1-bin.zip -o "$ROOT/gradle.zip"
  unzip -q "$ROOT/gradle.zip" -d "$GRADLE"
fi
cd "$ROOT"
python3 - <<'PY'
import os
from pathlib import Path
p=Path(os.environ['ROOT_PATH']) if 'ROOT_PATH' in os.environ else Path('.')
out=Path('android/app/src/main/java/tw/xinyun/smsreadonly/Secrets.java')
def j(s): return s.replace('\\','\\\\').replace('"','\\"')
out.write_text('package tw.xinyun.smsreadonly;\npublic final class Secrets { private Secrets(){} public static final String BASE_URL="%s"; public static final String DEVICE_TOKEN="%s"; }\n' % (j(os.environ['BRIDGE_BASE_URL'].rstrip('/')),j(os.environ['BRIDGE_DEVICE_TOKEN'])),encoding='utf-8')
PY
cd "$ROOT/android"
"$GRADLE/gradle-8.11.1/bin/gradle" --no-daemon :app:assembleDebug
mkdir -p "$ROOT/apk"
cp app/build/outputs/apk/debug/app-debug.apk "$ROOT/apk/xinyun-phone-bridge-0.4.0.apk"
sha256sum "$ROOT/apk/xinyun-phone-bridge-0.4.0.apk" | tee "$ROOT/apk/SHA256.txt"
